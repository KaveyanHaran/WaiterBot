import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Chef {
    private List<Item> items; // list of items in the order
    private float time; // total time it takes for the chef to cook all the items in the order
    private int calories; // total calories in the order
    public static float totalBill; // total amount of money owed for the order

    public Chef() {
        this.items = new ArrayList<>();
        this.time = 0;
        this.calories = 0;
        this.totalBill = 0;
    }

    public void addItem(Item item) {
        items.add(item);
        time += item.get_time();
        calories += item.get_calories();
        totalBill += item.get_price();
    }

    public void removeItem(Item item) {
        if (items.remove(item)) {
            time -= item.get_time();
            calories -= item.get_calories();
            totalBill -= item.get_price();
        }
    }

    public void clearOrder() {
        items.clear();
        time = 0;
        calories = 0;
        totalBill = 0;
    }

    public List<Item> getItems() {
        return items;
    }

    public float getTime() {
        return time;
    }

    public int getCalories() {
        return calories;
    }

    public float getTotalBill() {
        return totalBill;
    }

public static void main(String[] args) {
    Chef chef = new Chef();
    Scanner scan;
    scan = new Scanner( System.in );


    // Display the chef's order
    System.out.println("Chef's Order:");
    List<Item> items = chef.getItems();
    for (Item item : items) {
        System.out.println(item.get_name(scan) + " - $" + item.get_price());
    }

    // Display total time, calories, and bill
    System.out.println("Total Time: " + chef.getTime() + " minutes");
    System.out.println("Total Calories: " + chef.getCalories());
    System.out.println("Total Bill: $" + chef.getTotalBill());
    }  
}