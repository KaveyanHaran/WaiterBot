
import java.util.Scanner;
import java.util.ArrayList;

public class Item {
    
    
    
    private double price; 
    private int calories;
    private double time; 
    private String name;

    public  Item(String n, double p, int c, double t){
        price = p;
        calories = c;
        time = t;
        name = n;
   }
    public String get_name(Scanner scan){ //asks which item the user wants
        //Scanner scan;
        //scan = new Scanner( System.in );
        System.out.print("which item do you want?");
        //scan.close();
        
        return scan.nextLine();
       
   }

    /*public  double get_price(){ //gets the price for the certain item
        Categories category = new Categories("",Categories.itemList);
        String catName = Categories.get_name();
        
        for (int num =0; num<category.get_items(catName).length; num++){ 
            calories = (category.get_items(catName)[num].length());
        }
        
        
        return price;
    }
    public  int get_calories(){ //gets the calories for the certain item
        
        Categories category = new Categories("",Categories.itemList);
        String catName = Categories.get_name();
        for (int num =0; num<category.get_items(catName).size(); num++){
            calories = category.get_items(catName).get(num);
        }
        return calories;
        
    }

    public  double get_time(){ //gets the time it takes to make the certain item
        Categories category = new Categories("",Categories.itemList);
        String catName = Categories.get_name();
        for (int num =0; num<category.get_items(catName).size(); num++){
            time = ((category.get_items(catName)).get(num).size()*15)*0.01;
        }
        return time;
    }
*/

    public static String askForItem(String catName, Scanner scan){ 
        Item entry = new Item("",0.0,0,0.0);
        Categories category = new Categories("",Categories.itemList);
        System.out.println();

        System.out.println("The items for this category are: ");
        for (int num = 0; num<category.get_items(catName).size();num++){ //loops through the list of items in the category 
            System.out.println(category.get_items(catName).get(num));
        }
        System.out.println();

        return entry.get_name(scan);




    }

}
