import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Menu {
    private String name;
    private List<String> categories;
    public static int choice;

    public Menu(String name, List<String> categories) {
        this.name = name;
        this.categories = categories;
    }

    public String get_name() {
        return name;
    }
    
    public static String meal() {
        Scanner scanner = new Scanner(System.in);
       
        choice = scanner.nextInt();        

        if (choice == 1) {
            return "Breakfast";
        } else if (choice == 2) {
            return "Lunch";
        } else if (choice == 3) {
            return "Dinner";
        } else {
            System.out.println("Invalid choice. Please try again.");
            return meal();
        }
        
    }

    public List<String> get_categories() {
        return categories;
    }

   

    public String selectCategory() {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Please choose a category:");

    for (int i = 0; i < categories.size(); i++) {
        String category = categories.get(i);
        System.out.println((i + 1) + ". " + category);
    }

    int choice = scanner.nextInt();
    scanner.nextLine(); // Consume the newline character
    scanner.close();

    if (choice >= 1 && choice <= categories.size()) {
        return categories.get(choice - 1);
    } else {
        System.out.println("Invalid choice. Please try again.");
        return selectCategory();
    }
    
}
    

    public static void main(String[] args) {
        List<String> categories = new ArrayList<>();


        Menu menu = new Menu("Restaurant Menu", categories);

       

       

        // Get the chosen meal
        System.out.println("Please choose a meal:");
        System.out.println("1. Breakfast");
        System.out.println("2. Lunch");
        System.out.println("3. Dinner");
        String meal = menu.meal();
        System.out.println("Chosen Meal: " + meal);
    }
}