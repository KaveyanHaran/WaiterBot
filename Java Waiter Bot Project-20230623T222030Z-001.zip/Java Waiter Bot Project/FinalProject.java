

/*
calls all the classes and their main methods. 
loops untill the user does not want to anything else
*/
import java.util.Scanner;
import java.util.ArrayList;

public class FinalProject {
    

   
    public static void main(String[] args){
        int more =1;
        Scanner scan;
        scan = new Scanner( System.in );

        
        ArrayList<Item> MainCourseListB = new ArrayList<Item>();//make main course breakfast array list
        ArrayList<Item> MainCourseListL = new ArrayList<Item>();//make main course lunch array list
        ArrayList<Item> MainCourseListD = new ArrayList<Item>();//make main course dinner array list

        ArrayList<Item> AppetizerListB = new ArrayList<Item>();//make appetizer breakfast array list
        ArrayList<Item> AppetizerListL = new ArrayList<Item>();//make appetizer lunch array list
        ArrayList<Item> AppetizerListD = new ArrayList<Item>();//make appetizer dinner array list

        ArrayList<Item> DrinkList = new ArrayList<Item>();//make Drinks array list

        ArrayList<Item> DessertList = new ArrayList<Item>();//make dessert array list
           

        

        //initialize the breakfast main course
            Item Pancakes = new Item("Pancakes", 3.99, 60, 2.0);
            Item Waffles = new Item("Cheeseburger", 3.99, 60, 2.0);
            Item EggsAndBacon = new Item("Eggs & Bacon", 3.99, 100, 2.0);
            Item FrenchToast = new Item("French Toast", 3.99, 150, 2.0);
            Item FriedChicken = new Item("Fried Chicken", 5.99, 320, 5.0);
            //add items to main course lunch array list
                MainCourseListB.add(Pancakes);
                MainCourseListB.add(Waffles);
                MainCourseListB.add(EggsAndBacon);
                MainCourseListB.add(FrenchToast);
                MainCourseListB.add(FriedChicken);
                Categories MainCourseB = new Categories("Main Course, Breakfast ver.", MainCourseListB);


        //initialize the lunch main course
            Item Hamburger = new Item("Hamburger", 5.99, 550, 2.0);
            Item Cheeseburger = new Item("Cheeseburger", 5.99, 570, 2.0);
            Item Steak = new Item("Steak", 15.99, 700, 7.0);
            Item HotDog = new Item("Hot dog", 5.99, 550, 2.0);
            //add items to main course lunch array list
                MainCourseListL.add(Hamburger);
                MainCourseListL.add(Cheeseburger);
                MainCourseListL.add(Steak);
                MainCourseListL.add(FriedChicken);
                Categories MainCourseL = new Categories("Main Course, Lunch ver.", MainCourseListL);


        //initialize the dinner main course
            Item SpaghettiAndMeatballs = new Item("Spaghetti & Meatballs", 11.99, 220, 7.0);
            //add items to main course lunch array list
                MainCourseListD.add(Cheeseburger);
                MainCourseListD.add(SpaghettiAndMeatballs);
                MainCourseListD.add(Steak);
                MainCourseListD.add(HotDog);
                MainCourseListD.add(FriedChicken);
                Categories MainCourseD = new Categories("Main Course, Dinner ver.", MainCourseListD);


        //initialize the breakfast Appetizer
            Item Eggs = new Item("Eggs", 0.99, 80, 2.5);
            Item Toasts = new Item("Cheeseburger", 0.99, 75, 2.5);
            Item HashBrowns = new Item("Eggs & Bacon", 0.99, 470, 2.5);
            //add items to main course lunch array list
                AppetizerListB.add(Eggs);
                AppetizerListB.add(Toasts);
                AppetizerListB.add(HashBrowns);
                Categories AppetizerB = new Categories("Appetizer, Breakfast ver.", AppetizerListB);

                
        //initialize the Lunch Appetizer
            Item FrenchFries = new Item("French Fries", 0.99, 60, 2.0);
            Item Salad = new Item("Salad", 0.99, 300, 1.0);
            Item OnionRings = new Item("Onion Rings", 0.99, 480, 2.0);
            //add items to main course lunch array list
                AppetizerListL.add(Eggs);
                AppetizerListL.add(Toasts);
                AppetizerListL.add(HashBrowns);
                Categories AppetizerL = new Categories("Appetizer, Lunch ver.", AppetizerListL);


        //initialize the dinner Appetizer
            Item GrilledVegetables = new Item("Grilled Vegetables", 0.99, 110, 0.5);
            //add items to main course lunch array list
                AppetizerListD.add(GrilledVegetables);
                AppetizerListD.add(FrenchFries);
                AppetizerListD.add(Salad);
                AppetizerListD.add(OnionRings);

                Categories AppetizerD = new Categories("Appetizer, Dinner ver.", AppetizerListD);
               
               


        //initialize the drinks
        Item Soda = new Item("Soda", 3.99, 100, 0.3);
        Item Lemonade = new Item("Lemonade", 3.99, 100, 0.5);
        Item Water = new Item("Water", 0.00, 0, 0.0);
        Item Milkshake = new Item("Milkshake", 4.99, 200, 2.5);
            //add items to drinks array list
                DrinkList.add(Soda);
                DrinkList.add(Lemonade);
                DrinkList.add(Water);
                DrinkList.add(Milkshake);
                Categories drink = new Categories("Drinks", DrinkList);

                
        //initialize the desserts
            Item VanillaIcecream = new Item("Vanilla Ice cream", 3.99, 100, 0.5);
            Item ChocolateIcecream = new Item("Vanilla Ice cream", 3.99, 100, 0.5);
            Item MatchaIcecream = new Item("Matcha Ice cream", 3.99, 100, 0.5);
                //add items to drinks array list
                    DrinkList.add(VanillaIcecream);
                    DrinkList.add(ChocolateIcecream);
                    DrinkList.add(MatchaIcecream);
                    Categories desserts = new Categories("Desserts", DessertList);



        System.out.println();
        System.out.println("what is your name? ");
        String username = scan.nextLine(); // asks the user their name
        System.out.println();
        String capitalizedUsername = username.substring(0, 1).toUpperCase() + username.substring(1);

        System.out.println("Hello " + capitalizedUsername + "!");
        System.out.println();
        Menu.main(args); //calls main method in menu 

        while(more ==1){ //loops until the user doesnt want anything else
            int realCount = 0;
            int count = 0;
            int num = 0;
           
            Categories category = new Categories("",Categories.itemList);
            String catName = Categories.main(args); //calls main method in categories class.
            System.out.println(catName); 
            
            for (count = 0; count<category.get_items(catName).size();count ++){
                System.out.println(category.get_items(catName).get(count)); 
            }// loops through the array and prints out all of the elements

            String name =  Item.askForItem(catName, scan); //calls main method in Item class

            for (num=0; num<category.get_items(catName).size(); num++) {
                if ((category.get_items(catName).get(num)).equals("")) {
                    
                    realCount++;
                }

            }
            if (realCount >=1){
                System.out.println();
                System.out.println("do you want anything else? (1 = yes, 0 = no)"); //asks if the user wants anything else 
                more = scan.nextInt();
                System.out.println();
            }
            else if (realCount <1){
                System.out.println();
                System.out.println("Invalid choice. Please try again.");
                more = 1;
                System.out.println();
            }
            
        }
        System.out.println("Here");
        Tip.main(args);
        System.out.println("There");
        Chef.main(args);

       
        scan.close();
    
    }


    
        
            

}

/*


Menu
   Lunch
        Drink
            Lemonade
            Pepsi
            Coke

        Appetizers

        Main course


Menu breakfast = new Menu(...)
Menu lunch = new Menu(...)

Item i1 = Item("pepsi", 2, 3, 4);
Item i2 = Item("lemonade", 2,3, 4);
ArrayList<Item> itemList = new ArrayList<Item>();
itemList.add(i1);
itemList.add(i2);
Category drink = new Category("Drinks", itemList)
....
ArrayList<Category> cListl = new ArrayList<Category>();
cList.add(drink);
cList.add(appetizer)
Menu dinner = new Menu("Breakfast", cList)


*/

